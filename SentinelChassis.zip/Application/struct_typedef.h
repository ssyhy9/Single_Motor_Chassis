#ifndef STRUCT_TYPEDEF_H
#define STRUCT_TYPEDEF_H

typedef unsigned char bool_t;

#endif



